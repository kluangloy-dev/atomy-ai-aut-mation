export default function Home(){ return (<h1>Atomy AI Automation</h1>); }
