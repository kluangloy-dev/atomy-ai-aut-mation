# Atomy AI Automation

Basic Next.js site.
